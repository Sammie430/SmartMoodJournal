package com.example.smartmoodjournal

data class ChatMessage(
    val message: String,
    val isUser: Boolean
)
