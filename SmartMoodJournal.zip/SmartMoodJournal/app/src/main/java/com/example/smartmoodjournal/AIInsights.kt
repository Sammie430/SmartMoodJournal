package com.example.smartmoodjournal

data class AIInsights(
    val message: String
)
