package com.example.smartmoodjournal

data class AIResponse(
    val message: String
)
